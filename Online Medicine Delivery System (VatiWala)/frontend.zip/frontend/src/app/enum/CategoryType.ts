export enum CategoryType {
    "Allopathy", "Homeopathy", "Ayurveda Products", "Covid Essentials"
}
