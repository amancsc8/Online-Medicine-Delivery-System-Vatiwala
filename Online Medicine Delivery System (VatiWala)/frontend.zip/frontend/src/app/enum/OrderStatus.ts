export enum OrderStatus {
    "New",
    "Fulfilled",
    "Cancelled"
}
