-- the order of values is related to the name of field.
-- Updating is necessary, if the name is changed



INSERT INTO "public"."order_main" VALUES (2, 'New bus Station, Kanpur, Uttar Pradesh', 'customer2@email.com', 'customer2', '9876543210', '2022-06-20 12:52:20.439', 1110.00, 1, '2022-06-20 12:52:20.439');
INSERT INTO "public"."order_main" VALUES (1, 'Fazalganj, Kanpur, UP', 'customer1@email.com', 'customer1', '1234567890', '2022-06-20 13:01:06.943', 1300.00, 1, '2022-06-20 13:02:56.498');

-- ----------------------------
-- Table structure for product_category

-- ----------------------------
-- Records of product_category
-- ----------------------------
INSERT INTO "public"."product_category" VALUES (2147483641, 'Allopathy', 0, '2018-03-09 23:03:26', '2018-03-10 00:15:27');
INSERT INTO "public"."product_category" VALUES (2147483642, 'Ayurveda Products', 2, '2018-03-10 00:15:02', '2018-03-10 00:15:21');
INSERT INTO "public"."product_category" VALUES (2147483644, 'Covid Essentials', 3, '2018-03-10 01:01:09', '2018-03-10 01:01:09');
INSERT INTO "public"."product_category" VALUES (2147483645, 'Homeopathy', 1, '2018-03-10 00:26:05', '2018-03-10 00:26:05');


-- ----------------------------
-- Records of product_in_order
-- ----------------------------
INSERT INTO "public"."product_in_order" VALUES (2147483642, 0,1,'Books for learning Java', 'https://images-na.ssl-images-amazon.com/images/I/41f6Rd6ZEPL._SX363_BO1,204,203,200_.jpg', 'B0001', 'Core Java', 30.00,96,NULL, 2147483641);
INSERT INTO "public"."product_in_order" VALUES (2147483644, 0,1, 'Learn Spring', 'https://images-na.ssl-images-amazon.com/images/I/51gHy16h5TL._SX397_BO1,204,203,200_.jpg', 'B0002', 'Spring In Action', 20.00,195,NULL, 2147483643);
INSERT INTO "public"."product_in_order" VALUES (2147483646, 1,1, 'Kids Party Food', 'https://m.media-amazon.com/images/I/71McA0wAMzL._SL1399_.jpg', 'F0001', 'Chicken', 4.00,57,NULL, 2147483645);
INSERT INTO "public"."product_in_order" VALUES (2147483648, 3,1,'Awesome', 'https://starbuckssecretmenu.net/wp-content/uploads/2017/06/Starbucks-Violet-Drink.jpg', 'D0002', 'Starbucks Violet Drink', 2.00,200,NULL, 2147483647);
INSERT INTO "public"."product_in_order" VALUES (2147483640, 1,1, 'Kids Party Food', 'https://m.media-amazon.com/images/I/71McA0wAMzL._SL1399_.jpg', 'F0001', 'Chicken', 4.00,57,NULL, 2147483649);
INSERT INTO "public"."product_in_order" VALUES (2147483641, 2,1, 'Boys Clothes', 'https://d2ul0w83gls0j4.cloudfront.net/taxonomy/300/0102/20171024151632.jpg', 'C0002', 'Shirts', 13.00,108,NULL, 2147483649);
INSERT INTO "public"."product_in_order" VALUES (2147483632, 1,1, 'Family s', 'http://cdn1.thecomeback.com/wp-content/uploads/2017/05/mcdonalds_food-832x447.png', 'F0002', 'McDonald‘s Food', 20.00,22,NULL, 2147483649);
INSERT INTO "public"."product_in_order" VALUES (2147483643, 0,1, 'Books for learning Java', 'https://images-na.ssl-images-amazon.com/images/I/41f6Rd6ZEPL._SX363_BO1,204,203,200_.jpg', 'B0001', 'Core Java', 30.00,96,NULL, 2147483648);
INSERT INTO "public"."product_in_order" VALUES (2147483634, 2,1, 'Under Armour', 'https://assets.academy.com/mgen/33/20088533.jpg?is=500,500', 'C0001', 'T-shirt', 10.00, 109,NULL, 2147483649);
INSERT INTO "public"."product_in_order" VALUES (2147483636, 0,1, 'Java SE', 'https://images-na.ssl-images-amazon.com/images/I/51S8VRHA2FL._SX357_BO1,204,203,200_.jpg', 'B0005', 'Thinking in Java', 30.00, 199,NULL,2147483645);
INSERT INTO "public"."product_in_order" VALUES (2147483647, 3,1, 'Awesome', 'https://starbuckssecretmenu.net/wp-content/uploads/2017/06/Starbucks-Violet-Drink.jpg', 'D0002', 'Starbucks Violet Drink', 2.00,200,NULL, 2147483645);
INSERT INTO "public"."product_in_order" VALUES (2147483638, 0,1, 'Java SE', 'https://www.pearsonhighered.com/assets/bigcovers/0/1/3/2/0132778041.jpg', 'B0004', 'Effective Java', 30.00,199,NULL, 2147483645);
INSERT INTO "public"."product_in_order" VALUES (2147483649, 0,1, 'Books for learning Java', 'https://images-na.ssl-images-amazon.com/images/I/41f6Rd6ZEPL._SX363_BO1,204,203,200_.jpg', 'B0001', 'Core Java', 30.00,  96,NULL,2147483645);
INSERT INTO "public"."product_in_order" VALUES (2147483631, 1,1, 'Family s', 'http://cdn1.thecomeback.com/wp-content/uploads/2017/05/mcdonalds_food-832x447.png', 'F0002', 'McDonald‘s Food', 20.00,  22,null ,2147483640);
INSERT INTO "public"."product_in_order" VALUES (2147483633, 1,1, 'Kids Party Food', 'https://m.media-amazon.com/images/I/71McA0wAMzL._SL1399_.jpg', 'F0001', 'Chicken', 4.00, 57, null ,2147483642);


-- ----------------------------
-- Records of product_info
-- ----------------------------
INSERT INTO "public"."product_info" VALUES ('B0003', 0, '2018-03-10 10:37:39', 'For daily health and a fresh mind', 'https://static.oxinis.com/healthmug/image/product/94910-1-400.webp', 'Revital H Soft Gel Capsule (10caps)', 110.00, 0, 200, '2018-03-10 19:42:02');
INSERT INTO "public"."product_info" VALUES ('B0001', 0, '2018-03-10 06:44:25', 'Helps to counter Vitamin B deficiency, and assists in promoting a healthy nervous system', 'https://static.oxinis.com/healthmug/image/product/117616-4-400.webp', 'Neurobion Forte Tablet (30tab)', 34.00, 0, 100, '2018-03-10 06:44:25');
INSERT INTO "public"."product_info" VALUES ('B0004', 0, '2018-03-10 10:39:29', 'Tablet helps relieve pain and fever', 'https://m.media-amazon.com/images/I/71McA0wAMzL._SL1399_.jpg', 'Dolo 500mg (10tab)', 16.96, 0, 240, '2018-03-10 10:39:32');
INSERT INTO "public"."product_info" VALUES ('B0005', 0, '2018-03-10 10:40:35', 'Zincovit Drops is a multi-vitamin which make it an important dietary supplement for the growth of children', 'https://static.oxinis.com/healthmug/image/product/112670-1-400.webp', 'Zincovit Drop (15ml)', 50.00, 0, 190, '2018-03-10 10:40:35');
INSERT INTO "public"."product_info" VALUES ('B0002', 0, '2018-03-10 10:35:43', 'Assists in managing the levels of Vitamin E in the body, contains anti-oxidants', 'https://static.oxinis.com/healthmug/image/product/117573-4-400.webp', 'Evion Capsule (400mg) (10caps)', 35.00, 0, 195, '2018-03-10 10:35:43');
INSERT INTO "public"."product_info" VALUES ('B0006', 0, '2018-03-10 10:35:43', 'Assists in keeping the bones and teeth strong and healthy', 'https://static.oxinis.com/healthmug/image/product/79425-1-400.webp', 'Calcirol Sachet 60K (1g)', 56.00, 0, 198, '2018-03-10 10:35:43');
INSERT INTO "public"."product_info" VALUES ('B0007', 0, '2018-03-10 10:35:43', 'Abbott Digene Tablet helps to relieve symptoms of extra gas such as bloating and feeling of discomfort in the stomach', 'https://static.oxinis.com/healthmug/image/product/135283-1-400.webp', 'Digene Tablet Mint (15tab)', 21.00, 0, 196, '2018-03-10 10:35:43');
INSERT INTO "public"."product_info" VALUES ('B0008', 0, '2018-03-10 10:35:43', 'It helps replenish calcium daily and helps build strong bones for your child', 'https://static.oxinis.com/healthmug/image/product/110613-3-400.webp', 'Ostocalcium B12 Child Syrup Banana (200ml)', 166.00, 0, 188, '2018-03-10 10:35:43');
INSERT INTO "public"."product_info" VALUES ('B0009', 0, '2018-03-10 10:35:43', 'Sugar free nicotine chewing gums that helps you quit smoking', 'https://static.oxinis.com/healthmug/image/product/137438-1-400.webp', 'Nicotex Chewing Gums Sugar Free (4mg) Mint Plus (9pcs)', 105.00, 0, 204, '2018-03-10 10:35:43');
INSERT INTO "public"."product_info" VALUES ('B0010', 0, '2018-03-10 10:35:43', 'Helps in the treatment of burn injuries, minor cuts and wounds effectively', 'https://static.oxinis.com/healthmug/image/product/130217-1-400.webp', 'Burnol The Original Burns Cream (10g)', 56.00, 0, 345, '2018-03-10 10:35:43');

INSERT INTO "public"."product_info" VALUES ('F0001', 1, '2018-03-10 12:15:05', 'Used in Eye Strain,Headaches,Blurred Vision,Dryness & Redness of Eyes', 'https://static.oxinis.com/healthmug/image/product/2860-5-400.webp', 'Willmar Schwabe Germany Cineraria Maritima Eye Drops (Without Alcohol) (10ml)', 150.00, 0, 150, '2018-03-10 12:15:10');
INSERT INTO "public"."product_info" VALUES ('F0002', 1, '2018-03-10 12:16:44', 'Helps to control Hair Loss, Graying of hair, thin hair, alopecia', 'https://static.oxinis.com/healthmug/image/product/411-2-400.webp', 'Dr. Reckeweg R89 (Lipocol) (30ml)', 285.00, 0, 220, '2018-03-10 12:16:44');
INSERT INTO "public"."product_info" VALUES ('F0003', 1, '2018-03-10 12:16:44', 'Cervical Spondolysis, Pain and Stiffness Neck, Vertigo and Headache', 'https://static.oxinis.com/healthmug/image/product/5640-1-400.webp', 'Dr. Bhargava Spondin Drops (30ml)', 170.00, 0, 210, '2018-03-10 12:16:44');
INSERT INTO "public"."product_info" VALUES ('F0004', 1, '2018-03-10 12:16:44', 'Relieves Sour Eructations, Heart Burn, Flatulence, Hyperacidity, Gastritis', 'https://static.oxinis.com/healthmug/image/product/503-2-400.webp', 'SBL Nixocid Tabs (25g)', 140.00, 0, 290, '2018-03-10 12:16:44');
INSERT INTO "public"."product_info" VALUES ('F0005', 1, '2018-03-10 12:16:44', 'Sore Throat, Hoarseness with Loss of Voice, Laryngitis and Pharyngitis', 'https://static.oxinis.com/healthmug/image/product/3030-2-400.webp', 'Bakson Throat Aid Tablets (75tab)', 185.00, 0, 209, '2018-03-10 12:16:44');
INSERT INTO "public"."product_info" VALUES ('F0006', 1, '2018-03-10 12:16:44', 'Regulates Lowered Blood pressure, Weakness, Suffocation, Breathlessness', 'https://static.oxinis.com/healthmug/image/product/5505-1-400.webp', 'New Life NL-12 (Low Blood Pressure Drops) (30ml)', 140.00, 0, 189, '2018-03-10 12:16:44');
INSERT INTO "public"."product_info" VALUES ('F0007', 1, '2018-03-10 12:16:44', 'Helps in managing anxiety, difficult sleep and disheartedness after loss of loved ones', 'https://static.oxinis.com/healthmug/image/product/2644-1-400.webp', 'New Life Bach Flower Star Of Bethlehem (30ml)', 100.00, 0, 193, '2018-03-10 12:16:44');
INSERT INTO "public"."product_info" VALUES ('F0008', 1, '2018-03-10 12:16:44', 'For High Blood Cholesterol Levels, Triglycerides, Improves Circulation', 'https://static.oxinis.com/healthmug/image/product/5496-2-400.webp', 'New Life NL-3 (Blood Cholesterol Drops) (30ml)', 140.00, 0, 218, '2018-03-10 12:16:44');
INSERT INTO "public"."product_info" VALUES ('F0009', 1, '2018-03-10 12:16:44', 'Helps in Bronchitis, Wheezing, Dry Cough with vomiting, breathless', 'https://static.oxinis.com/healthmug/image/product/2885-1-400.webp', 'Willmar Schwabe India Alpha Coff (Cough Syrup) (100ml)', 105.00, 0, 267, '2018-03-10 12:16:44');
INSERT INTO "public"."product_info" VALUES ('F0010', 1, '2018-03-10 12:16:44', 'For Flatulence, Gastritis, Indigestion, Bloating & Stomach Pain, acidity', 'https://static.oxinis.com/healthmug/image/product/5451-2-400.webp', 'Medisynth Gasgan Pills (25g)', 110.00, 0, 295, '2018-03-10 12:16:44');

INSERT INTO "public"."product_info" VALUES ('C0003', 2, '2018-03-10 12:12:46', 'Effective and long term relief from constipation', 'https://static.oxinis.com/healthmug/image/product/11529-1-400.webp', 'Divisa Herbal Pet Safa Granules (120g)', 115.00, 0, 230, '2018-03-10 12:12:46');
INSERT INTO "public"."product_info" VALUES ('C0001', 2, '2018-03-10 12:09:41', 'It helps in keeping the heart muscles healthy and strong and may give relief from excessive thirst', 'https://static.oxinis.com/healthmug/image/product/128831-1-400.webp', 'Dabur Arjun Chhal Churna (100g)', 80.00, 0, 110, '2018-03-10 12:09:41');
INSERT INTO "public"."product_info" VALUES ('C0002', 2, '2018-03-10 12:11:51', 'Expels Renal Calculi, Control High Uric Acid, Urinary Track Infection (UTI)', 'https://static.oxinis.com/healthmug/image/product/3123-1-400.webp', 'Himalaya Cystone Tablet (60tab)', 135.00, 0, 190, '2018-03-10 12:11:51');
INSERT INTO "public"."product_info" VALUES ('C0004', 2, '2018-03-10 12:12:46', 'For Mind Debility and Retardation, Senile Dementia, Age Related Memory.', 'https://static.oxinis.com/healthmug/image/product/11579-2-400.webp', 'Zandu Brento Syrup (200ml)', 150.00, 0, 250, '2018-03-10 12:12:46');
INSERT INTO "public"."product_info" VALUES ('C0005', 2, '2018-03-10 12:12:46', 'Relieve Eye Pain, Redness, Itching, Irritation, Conjunctivitis and Watery Eyes', 'https://static.oxinis.com/healthmug/image/product/3159-1-400.webp', 'Himalaya Opthacare Eye Drops (10ml)', 70.00, 0, 207, '2018-03-10 12:12:46');
INSERT INTO "public"."product_info" VALUES ('C0006', 2, '2018-03-10 12:12:46', 'Himalaya Shigru Tablet is an ideal remedy with Anti-Arthritic Properties, which relieves inflammation and swelling of joints', 'https://static.oxinis.com/healthmug/image/product/3260-1-400.webp', 'Himalaya Shigru Tablet (60tab)', 180.00, 0, 239, '2018-03-10 12:12:46');
INSERT INTO "public"."product_info" VALUES ('C0007', 2, '2018-03-10 12:12:46', 'Indicated in preventing premature graying of hair and offers a solution to a wide range of hair problems.', 'https://static.oxinis.com/healthmug/image/product/47455-1-400.webp', 'Kerala Ayurveda Neelibringadi Keram (200ml)', 115.00, 0, 257, '2018-03-10 12:12:46');
INSERT INTO "public"."product_info" VALUES ('C0008', 2, '2018-03-10 12:12:46', 'Ayurvedic formulation for sore throat, cough and chest congestion', 'https://static.oxinis.com/healthmug/image/product/140209-1-400.webp', 'Dabur Honitus Cough Syrup (200ml)', 185.00, 0, 288, '2018-03-10 12:12:46');
INSERT INTO "public"."product_info" VALUES ('C0009', 2, '2018-03-10 12:12:46', 'Arjuna Tablet Arjuna promotes a healthy cardiovascular system. The capsule helps to provide relief in angina, atherosclerosis', 'https://static.oxinis.com/healthmug/image/product/53521-2-400.webp', 'Sri Sri Tattva Arjuna Tablet (60tab)', 150.00, 0, 251, '2018-03-10 12:12:46');
INSERT INTO "public"."product_info" VALUES ('C0010', 2, '2018-03-10 12:12:46', 'Dabur Rheumatil Gel is a Ayurvedic formulation for relieving Joint Pain, Swelling, Stiffness, Muscular Strain and Sprains', 'https://static.oxinis.com/healthmug/image/product/5722-2-400.webp', 'Dabur Rheumatil Gel (30g)', 99.00, 0, 210, '2018-03-10 12:12:46');

INSERT INTO "public"."product_info" VALUES ('D0001', 3, '2018-03-10 06:51:03', 'Antiseptic liquid that cleans cuts and wounds, kills bacteria & virus protection', 'https://m.media-amazon.com/images/I/518jdiCjuXL._SL1000_.jpg', 'Dettol Antiseptic Liquid, 1 Litre', 331.00, 0, 100, '2018-03-10 12:04:13');
INSERT INTO "public"."product_info" VALUES ('D0002', 3, '2018-03-10 12:08:17', 'Alcohol based hand sanitizer, kills 99.99% of illness causing germs & sanitizes your hands', 'https://rukminim1.flixcart.com/image/612/612/kc29n680/hand-wash-sanitizer/f/g/2/500-total-hand-sanitizer-bottle-lifebuoy-original-imaft9msmgwdpgne.jpeg?q=70', 'LIFEBUOY Total Hand Sanitizer Bottle  (0.5 L)', 250.00, 0, 200, '2018-03-10 12:08:17');
INSERT INTO "public"."product_info" VALUES ('D0003', 3, '2018-03-10 12:08:17', '3 Ply Face Mask that covers mouth & nose to Prevent entry of infection causing viruses', 'https://static.oxinis.com/healthmug/image/product/127218-1-400.webp', 'VW 3 Ply Face Mask (100pcs)', 500.00, 0, 199, '2018-03-10 12:08:17');
INSERT INTO "public"."product_info" VALUES ('D0004', 3, '2018-03-10 12:08:17', 'For Self, Easy and Fast Infection Detection', 'https://static.oxinis.com/healthmug/image/product/171778-1-400.webp', 'Mylab CoviSelf COVID-19 Rapid Antigen Self-Test (1pcs)', 250.00, 0, 209, '2018-03-10 12:08:17');
INSERT INTO "public"."product_info" VALUES ('D0005', 3, '2018-03-10 12:08:17', 'Feravir 400 Tablet is an antiviral medicine. It is used for the treatment of mild to moderate coronavirus disease (COVID-19).', 'https://static.oxinis.com/healthmug/image/product/149807-2-400.webp', 'Feravir Tablets 400mg (Favipiravir) (10tab)', 1100.00, 0, 201, '2018-03-10 12:08:17');
INSERT INTO "public"."product_info" VALUES ('D0006', 3, '2018-03-10 12:08:17', 'For Self, Easy and Fast Infection Detection,Self Test Kit to get your accurate Covid result in just 15 minutes, easy to use, and can be used by anyone', 'https://static.oxinis.com/healthmug/image/product/171856-1-400.webp', 'Meril Diagnostics CoviFind Covid 19 Antigen Self Test Kit (1Kit)', 250.00, 0, 200, '2018-03-10 12:08:17');
INSERT INTO "public"."product_info" VALUES ('D0007', 3, '2018-03-10 12:08:17', 'Protection cap that covers head to prevent infection causing virsues', 'https://static.oxinis.com/healthmug/image/product/131499-1-400.webp', 'VW Covid-19 Protection Cap Disposabel Set (30pcs)',300.00, 0, 197, '2018-03-10 12:08:17');
INSERT INTO "public"."product_info" VALUES ('D0008', 3, '2018-03-10 12:08:17', 'Covid 19 Protection Lotion', 'https://static.oxinis.com/healthmug/image/product/171852-1-400.webp', 'Clensta International Covid 19 Protection Lotion (100ml)', 298.00, 0, 248, '2018-03-10 12:08:17');
INSERT INTO "public"."product_info" VALUES ('D0009', 3, '2018-03-10 12:08:17', 'Covi Pro is an immunity booster drink that helps in preventing infections and supports the immune system', 'https://static.oxinis.com/healthmug/image/product/150431-1-400.webp', 'Levanza Covi Pro SF Herbal Immunity Booster (200ml)', 299.00, 0, 250, '2018-03-10 12:08:17');
INSERT INTO "public"."product_info" VALUES ('D0010', 3, '2018-03-10 12:08:17', 'Herbal Canada Tulsi 100 Immunity Booster Drops provide the goodness of Tulsi that works as an immunity enhancer', 'https://static.oxinis.com/healthmug/image/product/180262-1-400.webp', 'Herbal Canada Tulsi 100 Immunity Booster Drops (50ml)', 270.00, 0, 290, '2018-03-10 12:08:17');

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO "public"."users" VALUES (2147483641, 't', 'New bus Station, Kanpur, Uttar Pradesh', 'customer1@email.com', 'customer1', '$2a$10$PrI5Gk9L.tSZiW9FXhTS8O8Mz9E97k2FZbFvGFFaSsiTUIl.TCrFu', '1234567890', 'ROLE_CUSTOMER');
INSERT INTO "public"."users" VALUES (2147483642, 't', 'Lucknow HQ (UP)', 'lucknow.hq@vatiwala.com', 'Lucknow HQ', '$2a$10$PrI5Gk9L.tSZiW9FXhTS8O8Mz9E97k2FZbFvGFFaSsiTUIl.TCrFu', '9998887770', 'ROLE_MANAGER');
INSERT INTO "public"."users" VALUES (2147483643, 't', 'Kanpur HUB (UP) ', 'kanpur.hub@vatiwala.com', 'Kanpur HUB', '$2a$10$PrI5Gk9L.tSZiW9FXhTS8O8Mz9E97k2FZbFvGFFaSsiTUIl.TCrFu', '1231231231', 'ROLE_EMPLOYEE');
INSERT INTO "public"."users" VALUES (2147483645, 't', 'Fazalganj, Kanpur, UP', 'customer2@email.com', 'customer2', '$2a$10$0oho5eUbDqKrLH026A2YXuCGnpq07xJpuG/Qu.PYb1VCvi2VMXWNi', '9876543210', 'ROLE_CUSTOMER');

-- ----------------------------
-- Records of cart
-- ----------------------------
INSERT INTO "public"."cart" VALUES (2147483641);
INSERT INTO "public"."cart" VALUES (2147483642);
INSERT INTO "public"."cart" VALUES (2147483643);
INSERT INTO "public"."cart" VALUES (2147483645);


