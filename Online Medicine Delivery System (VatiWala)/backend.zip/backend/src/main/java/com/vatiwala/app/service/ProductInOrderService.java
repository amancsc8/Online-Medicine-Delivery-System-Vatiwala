package com.vatiwala.app.service;

import com.vatiwala.app.entity.ProductInOrder;
import com.vatiwala.app.entity.User;

/**
 * Created By Zhu Lin on 1/3/2019.
 */
public interface ProductInOrderService {
    void update(String itemId, Integer quantity, User user);
    ProductInOrder findOne(String itemId, User user);
}
