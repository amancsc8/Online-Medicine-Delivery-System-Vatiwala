package com.vatiwala.app.enums;


public interface CodeEnum {
    Integer getCode();

}
